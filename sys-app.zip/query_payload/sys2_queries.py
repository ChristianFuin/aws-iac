
find_case_id_by_acc = """BUSINESS_QUERY """

get_cases_past_6_months = """BUSINESS_QUERY """
             
get_cust_cin = """BUSINESS_QUERY """             

find_case_id_by_cin = """BUSINESS_QUERY """

